import json
import os

import google.cloud.ml.features as features


def runs_on_cloud():
  env = json.loads(os.environ.get('TF_CONFIG', '{}'))
  return env.get('task', None)

class SensorFeatures(object):

  csv_columns = ('time', 'inserted_at', 'value')

  time = features.key('time')
  measurements = [
      features.numeric('inserted_at'), features.numeric('value')
  ]

